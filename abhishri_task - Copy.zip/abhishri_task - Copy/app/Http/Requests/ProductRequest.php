<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class ProductRequest extends FormRequest {

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize() {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules() {

        switch ($this->method()) {
            case 'POST': {
                    return [
                        'name' => 'required',
                        'price' => 'required',
                        'unique_product_code' => 'required|unique:products',
                        'package' => 'required',
                        'qty' => 'required',
                        'stock' => 'required',
                        'description' => 'required',
                        // 'image' => 'mimes:jpeg,png,jpg,gif|dimensions:max_width:100,max_height:100'
                    ];
                }
            case 'PUT': {
                    return [
                        'name' => 'required',
                        'price' => 'required',
                        'unique_product_code' => 'required',
                        'package' => 'required',
                        'qty' => 'required',
                        'stock' => 'required',
                        'description' => 'required',
                        // 'image' => 'mimes:jpeg,png,jpg,gif|dimensions:max_width:100,max_height:100'
                    ];
                }
            default:break;
        }
    }

}
