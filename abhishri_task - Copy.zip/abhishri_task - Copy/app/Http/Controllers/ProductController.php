<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests\ProductRequest;
use Yajra\Datatables\Datatables;
use App\Models\Product;
use DB;
use Session;
use Storage;

class ProductController extends Controller {

    /**
     * Display a listing of the resource.
     *
     * @return Response
     */
    public function index() {
        return view('products.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
    public function create() {
        return view('products.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @return Response
     */
    public function store(ProductRequest $request) {


        try {
            DB::beginTransaction();
            $product = new Product;
            $product->name = $request->name;
            $product->price = $request->price;
            $product->unique_product_code = $request->unique_product_code;
            $product->package = $request->package;
            $product->qty = $request->qty;
            $product->stock = $request->stock;
            $product->description = $request->description;
            $product->save();
            if ($request->hasFile('image')) {
                $images = [];
                foreach ($request->file('image') as $image) {
                    $path = $image->store('public/images');
                    $images[] = $path;
                }
                $product->image = implode(',', $images);
            }
        
            $product->update();
            DB::commit();
        } catch (QueryException $e) {
            DB::rollback();
            Session::flash('error', 'Something went wrong. Please try again.');
            return redirect()->back()->withInput();
        }
        Session::flash('success', 'Product added successfully!');
        return redirect('products');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return Response
     */
    public function show($id) {

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return Response
     */
    public function edit($id) {
        $data['product'] = Product::where('id', $id)->first();
        if (!$data['product']) {
            Session::flash('error', 'Product not found.');
            return redirect()->back();
        }
        return view('products.edit')->withdata($data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  int  $id
     * @return Response
     */
    public function update(ProductRequest $request, $id) {
        try {
            $product = Product::where('id', $id)->first();
            $dataArray = array(
                'name' => $request->name,
                'price' => $request->price,
                'unique_product_code' => $request->unique_product_code,
                'package' => $request->package,
                'qty' => $request->qty,
                'stock' => $request->stock,
                'description' => $request->description,
            );
            $filename = '';
            if ($request->file('image')) {
                $image = $request->file('image');
                $filename = time() . '.' . $image->getClientOriginalExtension();
                Storage::disk('public')->put($filename, file_get_contents($image));
                $dataArray['image'] = $filename;
            //    Storage::disk('public')->delete($product->image);
            }

            Product::where('id', $id)->update($dataArray);
        } catch (QueryException $e) {
            Session::flash('error', 'Something went wrong. Please try again');
            return redirect()->back();
        }
        Session::flash('success', 'Product update successfully.');
        return redirect()->route('products.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return Response
     */
    public function destroy($id) {
        try {
            $data['product'] = Product::where('id', $id)->first();
            if (!$data['product']) {
                Session::flash('error', 'Product not found.');
                return redirect()->back();
            }
          //  Storage::disk('public')->delete($data['product']->image);
            Product::where('id', $id)->delete();
        } catch (QueryException $e) {
            Session::flash('error', 'Something went wrong. Please try again');
            return redirect()->back();
        }
        Session::flash('success', 'Product deleted successfully.');
        return redirect('products');
    }

    /*
     * Products Data fetch using Datatables
     */

    public function productAjax() {
        $products = Product::orderBy('created_at', 'desc')->get();

        return Datatables::of($products)
                        ->addColumn('name', function ($product) {
                            return $product->name;
                        })
                        ->addColumn('price', function ($product) {
                            return $product->price;
                        })

                        ->addColumn('qty', function ($product) {
                            return $product->qty;
                        })
                        ->addColumn('description', function ($product) {
                            return $product->description;
                        })

                        ->addColumn('action', function ($product) {
                            $data = "<a href = '" . route('products.edit', $product->id) . "' class = 'btn btn-primary'>Edit</a>&nbsp";
                            $data .= \Form::open(['url' => 'products/' . $product->id, 'method' => 'DELETE', 'style' => 'display:inline;']);
                            $data .= \Form::submit('Delete', ['class' => 'btn btn-danger', 'onclick' => 'return confirm("Are you sure you want to delete?");']);
                            $data .= \Form::close();
                            return $data;
                        })
                        ->rawColumns(['action'])
                        ->make(true);
    }

}
