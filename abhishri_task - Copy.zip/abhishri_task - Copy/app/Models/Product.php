<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Product extends Model {

    use SoftDeletes;

    protected $fillable = [
        'name', 'price', 'unique_product_code', 'package', 'qty','stock','description','image'
    ];
    protected $appends = ['image_url'];


    public function getImageUrlAttribute() {
        $image_path = '';
        $image = $this->image;
        $path = 'storage/' . $image;
        $image_path = asset($path);
        return $image_path;
    }

}
