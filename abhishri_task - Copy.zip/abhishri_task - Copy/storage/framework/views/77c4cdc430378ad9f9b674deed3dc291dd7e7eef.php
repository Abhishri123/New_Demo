<?php $__env->startSection('content'); ?>
<?php $__env->startSection('pageCss'); ?>
<link rel="stylesheet" href="//code.jquery.com/ui/1.13.1/themes/base/jquery-ui.css">
<?php $__env->stopSection(); ?>
<ol class="breadcrumb">
    <li class="breadcrumb-item">
        <a href="#">Book</a>
    </li>
    <li class="breadcrumb-item active">Edit</li>
</ol>
<div class="card mb-3">
    <div class="card-header">
        <i class="fas fa-user-circle"></i>
        Edit Book</div>
    <div>
        <div class="card-body">
            <form method="post" action="<?php echo e(route('books.update',$data['book']->id)); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="form-group">
                    <div class="form-row">
                        <div class="col-md-5">
                            <div class="form-group">
                                <label for="Name">Book Name</label><span class="text-danger">*</span>
                                <input type="text" name="name" class="form-control" placeholder="Book Name" value="<?php echo e($data['book']->name); ?>">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <div class="form-row">
                        <div class="col-md-5">
                            <div class="form-group">
                                <label for="Name">Category</label><span class="text-danger">*</span>
                                <select class="form-control" name="category_id">
                                    <option value="">Select Category</option>
                                    <?php $__currentLoopData = $data['categories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $selected_cat = ($data['book']->category_id == $category->id) ?'selected':'' ?>
                                    <option value="<?php echo e($category->id); ?>" <?php echo e($selected_cat); ?> ><?php echo e($category->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <div class="form-row">
                        <div class="col-md-5">
                            <div class="form-group">
                                <label for="AutherName">Author Name</label>
                                <input type="text" name="author_name" class="form-control" placeholder="Author Name" value="<?php echo e($data['book']->author_name); ?>">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <div class="form-row">
                        <div class="col-md-5">
                            <div class="form-group">
                                <label for="PublishDate">Publish Date</label>
                                <input type="text" name="publish_date" id="publish_date" class="form-control" placeholder="Publish Date" value="<?php echo e($data['book']->publish_date); ?>">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <div class="form-row">
                        <div class="col-md-5">
                            <div class="form-group">
                                <label for="image">Image</label>
                                <input type="file" name="image" class="form-control" placeholder="Image"><br>
                                <?php if(isset($data['book']->image) && $data['book']->image != ''): ?>
                                    <img src='<?php echo e($data['book']->image_url); ?>' width='50' height='50'>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <button class="btn btn-primary">Update</button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('pageScript'); ?>
<script src="https://code.jquery.com/ui/1.13.1/jquery-ui.js"></script>
<script>
$(function () {
    $("#publish_date").datepicker({dateFormat: 'yy-mm-dd'});
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\demo\resources\views/books/edit.blade.php ENDPATH**/ ?>