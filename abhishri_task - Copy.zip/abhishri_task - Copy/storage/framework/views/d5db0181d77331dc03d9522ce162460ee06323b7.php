<ul class="sidebar navbar-nav">
    <li class="nav-item active">
        <a class="nav-link" href="<?php echo e(route('home')); ?>">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Dashboard</span>
        </a>
    </li>
     <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('categories.index')); ?>">
            <i class="fas fa-fw fa-list"></i>
            <span>Categories</span></a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('books.index')); ?>">
            <i class="fas fa-fw fa-book"></i>
            <span>Books</span></a>
    </li>
</ul><?php /**PATH C:\wamp64\www\demo\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>