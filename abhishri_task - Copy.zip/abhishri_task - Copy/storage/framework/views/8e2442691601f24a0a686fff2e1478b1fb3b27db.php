<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="">
        <meta name="author" content="">
        <title>Ankit Practical</title>
        <link href="<?php echo e(asset('theme/vendor/fontawesome-free/css/all.min.css')); ?>" rel="stylesheet" type="text/css">
        <link href="<?php echo e(asset('theme/vendor/datatables/dataTables.bootstrap4.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('theme/css/sb-admin.css')); ?>" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.css">
        <?php echo $__env->yieldContent('pageCss'); ?>
        <style>
            .container { margin: 150px auto; }
            body { font-family: 'Open Sans'; }
        </style>
    </head>
    <body id="page-top">
        <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div id="wrapper">
            <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div id="content-wrapper">
                <div class="container-fluid">
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
                <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
        <a class="scroll-to-top rounded" href="#page-top">
            <i class="fas fa-angle-up"></i>
        </a>
        <script src="<?php echo e(asset('theme/vendor/jquery/jquery.min.js')); ?>"></script>
        <script src="<?php echo e(asset('theme/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
        <script src="<?php echo e(asset('theme/js/sb-admin.min.js')); ?>"></script>
        <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
        <script>
<?php if(Session::has('success')): ?>
toastr.success("<?php echo e(Session::get('success')); ?>");
<?php endif; ?>
        <?php if(Session::has('info')): ?>
toastr.info("<?php echo e(Session::get('info')); ?>");
<?php endif; ?>
        <?php if(Session::has('warning')): ?>
toastr.warning("<?php echo e(Session::get('warning')); ?>");
<?php endif; ?>
        <?php if(Session::has('error')): ?>
toastr.error("<?php echo e(Session::get('error')); ?>");
<?php endif; ?>
        <?php if(count($errors) > 0): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
toastr.error("<?php echo e($error); ?>");
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        </script>
        <?php echo $__env->yieldContent('pageScript'); ?>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\ankit-practical\resources\views/layouts/app.blade.php ENDPATH**/ ?>