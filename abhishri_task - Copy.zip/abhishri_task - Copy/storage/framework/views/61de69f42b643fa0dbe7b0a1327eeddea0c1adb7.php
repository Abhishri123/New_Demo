<?php $__env->startSection('content'); ?>
<?php $__env->startSection('pageCss'); ?>
<link rel="stylesheet" href="//code.jquery.com/ui/1.13.1/themes/base/jquery-ui.css">
<?php $__env->stopSection(); ?>
<ol class="breadcrumb">
    <li class="breadcrumb-item">
        <a href="#">Products</a>
    </li>
    <li class="breadcrumb-item active">Add Product</li>
</ol>
<div class="card mb-3">
    <div class="card-header">
        <i class="fas fa-user-book"></i>
        Add Product</div>
    <div>
        <div class="card-body">
            <form method="post" action="<?php echo e(route('products.store')); ?>" enctype ='multipart/form-data'>
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <div class="form-row">
                        <div class="col-md-5">
                            <div class="form-group">
                                <label for="Name">Product Name</label><span class="text-danger">*</span>
                                <input type="text" name="name" class="form-control" placeholder="Product Name" value="<?php echo e(old('name')); ?>">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <div class="form-row">
                        <div class="col-md-5">
                            <div class="form-group">
                                <label for="Name">Package</label><span class="text-danger">*</span>
                                <select class="form-control" name="package">
                                    <option value="">Select Package</option>
                                    <option value="KG">KG</option>
                                    <option value="ML">ML</option>
                                    <option value="GM">GM</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <div class="form-row">
                        <div class="col-md-5">
                            <div class="form-group">
                                <label for="Name">Price</label><span class="text-danger">*</span>
                                <input type="text" name="price" class="form-control" placeholder="Price" value="<?php echo e(old('price')); ?>">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <div class="form-row">
                        <div class="col-md-5">
                            <div class="form-group">
                                <label for="unique_product_code">Product Code</label><span class="text-danger">*</span>
                                <input type="text" name="unique_product_code" id="unique_product_code" class="form-control" placeholder="Product Code" value="<?php echo e(old('unique_product_code')); ?>">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <div class="form-row">
                        <div class="col-md-5">
                            <div class="form-group">
                                <label for="Quantity">Quantity</label><span class="text-danger">*</span>
                                <input type="text" name="qty" class="form-control" placeholder="Quantity" value="<?php echo e(old('qty')); ?>">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <div class="form-row">
                        <div class="col-md-5">
                            <div class="form-group">
                                <label for="Quantity">Stock</label><span class="text-danger">*</span>
                                <input type="text" name="stock" class="form-control" placeholder="Stock" value="<?php echo e(old('stock')); ?>">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <div class="form-row">
                        <div class="col-md-5">
                            <div class="form-group">
                                <label for="Quantity">Description</label><span class="text-danger">*</span>
                                <textarea class="form-control" name="description"></textarea>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <div class="form-row">
                        <div class="col-md-5">
                            <div class="form-group">
                                <label for="image">Image</label>
                                <input type="file" name="image" class="form-control" placeholder="Image">
                            </div>
                        </div>
                    </div>
                </div>
                <button class="btn btn-primary">Save</button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('pageScript'); ?>
<script src="https://code.jquery.com/ui/1.13.1/jquery-ui.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ankit-practical\resources\views/products/create.blade.php ENDPATH**/ ?>