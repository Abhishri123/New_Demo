<?php $__env->startSection('content'); ?>
<?php $__env->startSection('pageCss'); ?>
<link href="<?php echo e(asset('theme/vendor/datatables/dataTables.bootstrap4.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<ol class="breadcrumb">
    <li class="breadcrumb-item">
        <a href="#">Categories</a>
    </li>
    <li class="breadcrumb-item active">Lists</li>
</ol>
<div class="card mb-3">
    <div class="card-header">
        <div class="float-left">
            <i class="fas fa-table"></i> Category Lists
        </div>
        <div class="float-right">
            <a class="btn btn-primary" href="<?php echo e(route('categories.create')); ?>">
                <span>Add Category</span></a>
        </div>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered" id="category" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Description</th>
                        <th>Action</th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('pageScript'); ?>
<script src="<?php echo e(asset('theme/vendor/datatables/jquery.dataTables.js')); ?>"></script>
<script src="<?php echo e(asset('theme/vendor/datatables/dataTables.bootstrap4.js')); ?>"></script>
<script>
$(document).ready(function () {
    $('#category').DataTable({
        processing: true,
        serverSide: true,
        ajax: "<?php echo e(route('categories.fetch')); ?>",
        columns: [
            {data: 'name', name: 'name'},
            {data: 'description', name: 'description'},
            {data: 'action', name: 'action'}
        ],
        order: [[0, 'desc']]
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\demo\resources\views/categories/index.blade.php ENDPATH**/ ?>