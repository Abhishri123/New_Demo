<ul class="sidebar navbar-nav">
    <li class="nav-item active">
        <a class="nav-link" href="<?php echo e(route('home')); ?>">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Dashboard</span>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('products.index')); ?>">
            <i class="fas fa-fw fa-book"></i>
            <span>Products</span></a>
    </li>
</ul>
<?php /**PATH C:\xampp\htdocs\ankit-practical\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>