@extends('layouts.app')
@section('content')
@section('pageCss')
<link href="{{ asset('theme/vendor/datatables/dataTables.bootstrap4.css') }}" rel="stylesheet">
@endsection
<ol class="breadcrumb">
    <li class="breadcrumb-item">
        <a href="#">Product</a>
    </li>
    <li class="breadcrumb-item active">Lists</li>
</ol>
<div class="card mb-3">
    <div class="card-header">
        <div class="float-left">
            <i class="fas fa-table"></i> Product Lists
        </div>
        <div class="float-right">
            <a class="btn btn-primary" href="{{ route('products.create') }}">
                <span>Add Product</span></a>
        </div>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered" id="users" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Price</th>
                        <th>Qty</th>
                        <th>Description</th>
                        <th>Action</th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>
</div>
@endsection
@section('pageScript')
<script src="{{ asset('theme/vendor/datatables/jquery.dataTables.js') }}"></script>
<script src="{{ asset('theme/vendor/datatables/dataTables.bootstrap4.js') }}"></script>
<script>
$(document).ready(function () {
    $('#users').DataTable({
        processing: true,
        serverSide: true,
        ajax: "{{ route('products.fetch') }}",
        columns: [
            {data: 'name', name: 'name'},
            {data: 'price', name: 'price'},
            {data: 'qty', name: 'qty'},
            {data: 'description', name: 'description'},
            {data: 'action', name: 'action'}
        ],
        order: [[0, 'desc']]
    }
    );
});
</script>
@endsection
